--@c:\dir_of_your_choosing\ldms_install.sql
--
--WHENEVER SQLERROR EXIT FAILURE
--SET TERM ON
--SET SERVEROUT ON
SET DEFINE   OFF
SET DOCUMENT OFF
SET HEADING  OFF

--SPOOL "c:\dir_of_your_choosing\ldms_installation_Log.TXT"
SPOOL "ldms_installation_Log.TXT"

-- Start installation of Fufilment objects 
PROMPT Starting ldms_install.sql
--
---------------------------------------
-- Drop existing tables
---------------------------------------
--
DROP TABLE EMPLOYEES;            
DROP TABLE DEPARTMENTS; 
--
---------------------------------------
-- Create TABLES
---------------------------------------
--
START create_ldms_tables.sql  
--
---------------------------------------
-- Populate Tables
---------------------------------------
--      
START populate_ldms_tables.sql
--
---------------------------------------
-- Create STORED PROCEDURES
---------------------------------------
START ldms_pkg.sql

PROMPT Finished script ldms_install.SQL

SPOOL OFF

PROMPT Please check log file c:\dir_of_your_choosing\ldms_installation_Log.TXT for any errors or warnings
SET DOCUMENT ON
--EXIT