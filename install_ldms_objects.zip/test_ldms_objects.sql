exec pkg_ldms_test.sp_ins_employee(90011,'Ken Warden', 'Developer', 90002, 65000, 3);

exec pkg_ldms_test.sp_emp_sal(90011, 5, 'DECREASE');

exec pkg_ldms_test.sp_emp_dept_change(90011, 4);

SET SERVEROUTPUT ON
DECLARE
  c sys_refcursor;
BEGIN
   pkg_ldms_test.sp_emp_by_dept(90011, 4, c);
   
   pkg_ldms_test.print_emp_by_dept(c);
END;
/

SET SERVEROUTPUT ON
DECLARE
  c sys_refcursor;
BEGIN
   pkg_ldms_test.sp_sal_by_dept(c);
   
   pkg_ldms_test.print_sal_by_dept(c);
END;
/