CREATE OR REPLACE PACKAGE pkg_ldms_test IS

--Returns salary for a specific employee
FUNCTION fn_get_employee_sal(pi_employee_id IN NUMBER) RETURN NUMBER;

--Creates a new employee in the employees table
PROCEDURE sp_ins_employee(pi_employee_id      IN NUMBER,                 
                          pi_employee_name    IN VARCHAR2, 
						  pi_job_title        IN VARCHAR2, 
						  pi_manager_id       IN NUMBER,
						  pi_salary           IN NUMBER,
						  pi_department_id    IN NUMBER                     
                         );
--Updates employee salary by a percentage up or down						 
PROCEDURE sp_emp_sal(pi_employee_id  IN NUMBER,                 
                     pi_pcent        IN NUMBER, 
				     pi_sal_change   IN VARCHAR2                 
                    );
					
--Update an employees dedails if the change Department
PROCEDURE sp_emp_dept_change(pi_employee_id    IN NUMBER,                 
				             pi_department_id  IN NUMBER                
                            );
							
--Returns employee details by department
PROCEDURE sp_emp_by_dept(pi_employee_id    IN NUMBER,                 
				         pi_department_id  IN VARCHAR2 DEFAULT NULL,               
                         po_result OUT sys_refcursor);
						 
--Provides total salsry details by department
PROCEDURE sp_sal_by_dept(po_result OUT sys_refcursor);

--Prints to screen output from PROCEDURE sp_emp_by_dept
PROCEDURE print_emp_by_dept( c in sys_refcursor );

--Prints to screen output from PROCEDURE sp_emp_by_dept
PROCEDURE print_sal_by_dept( c in sys_refcursor );

END pkg_ldms_test;
/

--
-------------------------------------------------------------------------------
--

CREATE OR REPLACE PACKAGE BODY pkg_ldms_test IS

--Returns salary for a specific employee
FUNCTION fn_get_employee_sal(pi_employee_id IN NUMBER) RETURN NUMBER
IS
  v_salary NUMBER;
BEGIN
  SELECT salary INTO v_salary
    FROM employees
   WHERE employee_id = pi_employee_id;
   
   RETURN v_salary;
EXCEPTION  
  WHEN OTHERS THEN 
    RETURN NULL;
END fn_get_employee_sal;
--
-------------------------------------------------------------------------------
--
--Creates a new employee in the employees table
PROCEDURE sp_ins_employee(pi_employee_id      IN NUMBER,                 
                          pi_employee_name    IN VARCHAR2, 
						  pi_job_title        IN VARCHAR2, 
						  pi_manager_id       IN NUMBER,
						  pi_salary           IN NUMBER,
						  pi_department_id    IN NUMBER                     
                         )
IS
BEGIN

	INSERT INTO EMPLOYEES 
	           (EMPLOYEE_ID, 
			    EMPLOYEE_NAME, 
				JOB_TITLE, 
				MANAGER_ID, 
				DATE_HIRED, 
				SALARY, 
				DEPARTMENT_ID)
	VALUES     (pi_employee_id, 
	            pi_employee_name, 
				pi_job_title, 
				pi_manager_id,
				SYSDATE,
			    pi_salary,
			    pi_department_id 
	      );
		  
    COMMIT;
	
EXCEPTION   
  WHEN OTHERS THEN
     ROLLBACK;
	 DBMS_OUTPUT.PUT_LINE(SQLERRM);
END sp_ins_employee;	
--
-------------------------------------------------------------------------------
--
--Updates employee salary by a percentage up or down
PROCEDURE sp_emp_sal(pi_employee_id  IN NUMBER,                 
                     pi_pcent        IN NUMBER, 
				     pi_sal_change   IN VARCHAR2                 
                    )
					
IS
   v_pcent_increase NUMBER := pi_pcent/100;
BEGIN

  IF pi_sal_change = 'INCREASE' THEN
     v_pcent_increase := 1 + v_pcent_increase;
  END IF;
  
  IF pi_sal_change = 'DECREASE' THEN
     v_pcent_increase := 1 - v_pcent_increase;
  END IF;
   
UPDATE EMPLOYEES
   SET salary = salary * v_pcent_increase
 WHERE employee_id = pi_employee_id;   

COMMIT;			

EXCEPTION   
  WHEN OTHERS THEN
     ROLLBACK;
	 DBMS_OUTPUT.PUT_LINE(SQLERRM);				
END sp_emp_sal;
--
-------------------------------------------------------------------------------
--
--Update an employees dedails if the change Department
PROCEDURE sp_emp_dept_change(pi_employee_id    IN NUMBER,                 
				             pi_department_id  IN NUMBER                 
                            )

IS
BEGIN
	
UPDATE EMPLOYEES
   SET department_id = pi_department_id
 WHERE employee_id = pi_employee_id;   
 
COMMIT;			

EXCEPTION   
  WHEN OTHERS THEN
     ROLLBACK;
	  DBMS_OUTPUT.PUT_LINE(SQLERRM);				
END sp_emp_dept_change;
--
-------------------------------------------------------------------------------
--
--Returns employee details by department
PROCEDURE sp_emp_by_dept(pi_employee_id    IN NUMBER,                 
				         pi_department_id  IN VARCHAR2 DEFAULT NULL,               
                         po_result OUT sys_refcursor)
IS
		  
BEGIN
  OPEN po_result FOR 
       SELECT emp.employee_id, emp.employee_name, dept.department
         FROM employees emp, departments dept
	    WHERE emp.department_id = dept.department_id
		  AND emp.department_id = pi_department_id;
EXCEPTION
   WHEN OTHERS THEN
      NULL;
END sp_emp_by_dept;
--
-------------------------------------------------------------------------------
--
--Provides total salary details by department
PROCEDURE sp_sal_by_dept(po_result OUT sys_refcursor)
IS
BEGIN
    OPEN po_result FOR 
	WITH tot_sal AS
	  (SELECT sum(salary) total_salary, department_id
         FROM employees  
	      GROUP BY Department_id
	   )
	   SELECT dept.department, ts.total_salary 
	     FROM departments dept, tot_sal ts
		WHERE ts.department_id = dept.department_id;

EXCEPTION
   WHEN OTHERS THEN
      NULL;

END sp_sal_by_dept;
--
-------------------------------------------------------------------------------
--
--Prints to screen output from PROCEDURE sp_emp_by_dept
PROCEDURE print_emp_by_dept( c in sys_refcursor )
IS
    v_emp_id     employees.employee_id%TYPE;
    v_emp_name   employees.employee_name%TYPE;
    v_department departments.department%TYPE;
BEGIN
  dbms_output.enable(10000000);
  LOOP
     FETCH c INTO v_emp_id, v_emp_name, v_department;
      EXIT WHEN c%notfound;
      dbms_output.put_line(v_emp_id||'  '|| RPAD(v_emp_name,50,' ')||RPAD(v_department,50,' '));
  END LOOP;
END print_emp_by_dept;			
--
-------------------------------------------------------------------------------
--
--Prints to screen output from PROCEDURE sp_emp_by_dept
PROCEDURE print_sal_by_dept( c in sys_refcursor )
IS
    v_tot_sal    NUMBER;
    v_department departments.department%TYPE;
BEGIN
  dbms_output.enable(10000000);
  LOOP
     FETCH c INTO v_department, v_tot_sal;
      EXIT WHEN c%notfound;
      dbms_output.put_line(RPAD(v_department,50,' ') ||v_tot_sal||'  ');
  END LOOP;
END print_sal_by_dept;					 
						 
--
-------------------------------------------------------------------------------
--

END pkg_ldms_test;
/