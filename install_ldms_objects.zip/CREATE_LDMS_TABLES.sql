CREATE TABLE DEPARTMENTS
(
  DEPARTMENT_ID      NUMBER(5)    NOT NULL,
  DEPARTMENT         VARCHAR2(50) NOT NULL, 
  LOCATION           VARCHAR2(50) NOT NULL
)
/

ALTER TABLE DEPARTMENTS
  ADD CONSTRAINT DEPT_ID_PK         
  PRIMARY KEY(DEPARTMENT_ID)
/      

comment on column departments.department_id IS 'The unique identifier for the department';
comment on column departments.department    IS 'The name of the department';
comment on column departments.location      IS 'The physical location of the department';

CREATE TABLE EMPLOYEES
(
  EMPLOYEE_ID        NUMBER(10)   NOT NULL,
  EMPLOYEE_NAME      VARCHAR2(50) NOT NULL, 
  JOB_TITLE          VARCHAR2(50) NOT NULL,
  MANAGER_ID         NUMBER(10),
  DATE_HIRED         DATE DEFAULT SYSDATE NOT NULL, 
  SALARY             NUMBER(10)   NOT NULL,
  DEPARTMENT_ID      NUMBER(5)    NOT NULL 
)
/

ALTER TABLE EMPLOYEES
  ADD CONSTRAINT EMPLOYEES_PK         
  PRIMARY KEY(EMPLOYEE_ID)
/      

ALTER TABLE EMPLOYEES 
  ADD (CONSTRAINT DEPARTMENT_ID_FK1       
  FOREIGN KEY(DEPARTMENT_ID) REFERENCES DEPARTMENTS(DEPARTMENT_ID) 
  DEFERRABLE INITIALLY IMMEDIATE)      
/

comment on column employees.employee_id   IS 'The unique identifier for the employee';
comment on column employees.EMPLOYEE_NAME IS 'The name of the employee';
comment on column employees.JOB_TITLE     IS 'The job role undertaken by the employee. Some employees may undertaken the same job role';
comment on column employees.MANAGER_ID    IS 'Line manager of the employee';
comment on column employees.DATE_HIRED    IS 'The date the employee was hired';
comment on column employees.SALARY        IS 'Current salary of the employee';
comment on column employees.DEPARTMENT_ID IS 'Each employee must belong to a department';


